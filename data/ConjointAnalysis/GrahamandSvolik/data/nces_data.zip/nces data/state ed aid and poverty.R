setwd(paste0("C:/Users/",Sys.getenv("USERNAME"),"/Dropbox/GrahamSvolik"))

library(readxl)
library(tidyverse)

poverty= read_excel("nces data/ncesdata_5F32AA8B.xlsx", skip=4)
budget = read_excel("nces data/ncesdata_8B6A6AF1.xlsx")

head(budget)
head(poverty)

d = left_join(
  budget %>% select(LEAID, StateRevenuePercent),
  poverty%>% select(LEAID, MSTATE, PercentPoverty)
) %>%
  mutate_at(vars(-MSTATE), as.numeric) %>%
  .[complete.cases(.),]

with(d, cor(StateRevenuePercent, PercentPoverty))

library(estimatr)
lm_robust(StateRevenuePercent ~ PercentPoverty + MSTATE, data = d) %>% tidy

rm(list=ls())
setwd("C:/Users/Matt/Dropbox/GrahamSvolik")
library(tidyverse)

flathead = read_csv("montana/flathead.csv")
lake     = read_csv("montana/lake.csv")
park     = read_csv("montana/park.csv")
sheridan = read_csv("montana/sheridan.csv")
stillwater = read_csv("montana/stillwater.csv")

lake = lake %>%
  rename(absent = absentee) %>%
  filter(office=="US representative") %>%
  select(-office) 

park = park %>%
  rename(absent = absentee) %>%
  filter(office=="US representative") %>%
  select(-office, -X11) 

stillwater = stillwater %>%
  rename(absent = absentee) %>%
  filter(office=="US representative") %>%
  select(-office, -X11)

flathead = flathead %>%
  mutate(
    candidate = recode(candidate, `RICK BRECKENRIDGE` = "Rick Breckenridge", `DENISE JUNEAU` = "Denise Juneau", `GREG GIANFORTE` = "Greg Gianforte", `MARK L WICKS` = "Mark L Wicks",
                       `ROB QUIST` = "Rob Quist", `RYAN ZINKE` = "Ryan Zinke", `WRITE-IN` = "Write-in")
  ) %>%
  rename(absent = abs)

sheridan = sheridan %>% rename(polls = electday, provisional = Prov) %>% mutate(county = "Sheridan")

mt = bind_rows(
  flathead, lake, park, sheridan, stillwater
)

mt = mt %>% mutate_at(vars(total, absent, polls, year), as.numeric)

mt = mt %>% filter(party=="Dem" | party=="Rep", grepl("representative", office) | is.na(office))

mt = mt %>% mutate(party = recode(party, Dem="voteD", Rep="voteR"))

mt = mt %>% select(-office, -provisional, -hand, -total, -registered)

mt = mt %>% 
  select(-candidate) %>%
  gather(method, votes, absent, polls) %>%
  spread(party, votes)

write_csv(mt, "montana/montana.csv")
